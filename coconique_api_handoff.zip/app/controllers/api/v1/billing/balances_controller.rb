module Api
  module V1
    module Billing
      class BalancesController < ApplicationController
        before_action :require_login!

        def show
          app_key = params.fetch(:app_key, ENV.fetch("CURRENT_APP_KEY", "sample_app"))
          balance = CreditBalance.find_or_create_for!(
            user: current_user,
            app_key: app_key
          )

          render_success(
            {
              credit_balance: {
                app_key: balance.app_key,
                balance: balance.balance
              }
            }
          )
        end
      end
    end
  end
end
