module Api
  module V1
    module Billing
      class CreditProductsController < ApplicationController
        before_action :require_login!

        def index
          app_key = params.fetch(:app_key, ENV.fetch("CURRENT_APP_KEY", "sample_app"))

          products = CreditProduct
            .active
            .where(app_key: app_key)
            .ordered

          render_success(
            {
              credit_products: products.map { |product| credit_product_json(product) }
            }
          )
        end

        private

        def credit_product_json(product)
          {
            id: product.id,
            app_key: product.app_key,
            code: product.code,
            name: product.name,
            description: product.description,
            amount_jpy: product.amount_jpy,
            credits: product.credits,
            active: product.active
          }
        end
      end
    end
  end
end
