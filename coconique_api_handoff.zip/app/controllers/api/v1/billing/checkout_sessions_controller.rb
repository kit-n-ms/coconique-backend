module Api
  module V1
    module Billing
      class CheckoutSessionsController < ApplicationController
        before_action :require_login!

        def create
          app_key = params.fetch(:app_key, ENV.fetch("CURRENT_APP_KEY", "sample_app"))
          product = CreditProduct.active.find_by!(
            app_key: app_key,
            code: params.require(:product_code)
          )

          stripe_customer = StripeCustomer.ensure_for!(user: current_user)

          success_url = ENV.fetch(
            "STRIPE_SUCCESS_URL",
            "http://localhost:5173/billing/success?session_id={CHECKOUT_SESSION_ID}"
          )

          cancel_url = ENV.fetch(
            "STRIPE_CANCEL_URL",
            "http://localhost:5173/billing/cancel"
          )

          payment = current_user.payment_checkout_sessions.create!(
            credit_product: product,
            stripe_customer: stripe_customer,
            status: "created",
            amount_total: product.amount_jpy,
            currency: "jpy",
            credits: product.credits,
            success_url: success_url,
            cancel_url: cancel_url,
            metadata: {
              app_key: app_key,
              product_code: product.code
            }
          )

          metadata = {
            payment_checkout_session_id: payment.id,
            user_id: current_user.id,
            app_key: app_key,
            product_code: product.code
          }

          session = Stripe::Checkout::Session.create(
            customer: stripe_customer.stripe_customer_id,
            mode: "payment",
            client_reference_id: payment.id.to_s,
            success_url: success_url,
            cancel_url: cancel_url,
            line_items: [
              {
                quantity: 1,
                price_data: {
                  currency: "jpy",
                  unit_amount: product.amount_jpy,
                  product_data: {
                    name: product.name,
                    description: product.description
                  }
                }
              }
            ],
            metadata: metadata,
            payment_intent_data: {
              metadata: metadata
            }
          )

          payment.update!(
            stripe_checkout_session_id: session.id,
            status: session.status || "open",
            expires_at: Time.at(session.expires_at)
          )

          AuditLog.record!(
            user: current_user,
            action: "billing.checkout_session.created",
            request: request,
            target: payment,
            metadata: {
              stripe_checkout_session_id: session.id,
              product_code: product.code,
              amount_jpy: product.amount_jpy,
              credits: product.credits
            }
          )

          render_success(
            {
              checkout_session: {
                id: payment.id,
                stripe_checkout_session_id: session.id,
                url: session.url,
                status: payment.status,
                amount_total: payment.amount_total,
                currency: payment.currency,
                credits: payment.credits
              }
            },
            status: :created
          )
        end
      end
    end
  end
end
