module Api
  module V1
    module Admin
      class UsersController < BaseController
        def index
          scope = User.includes(:user_profile, :coconique_safety_check_setting, :coconique_emergency_contacts, :coconique_user_restrictions).order(created_at: :desc)

          requested_status = params[:status].presence || params[:restriction_status].presence || params[:restrictionStatus].presence

          if requested_status.present? && CoconiqueUserRestriction.statuses.key?(requested_status)
            active_restriction_user_ids = CoconiqueUserRestriction
              .active
              .where(status: requested_status)
              .select(:user_id)
            scope = scope.where(id: active_restriction_user_ids)
          elsif requested_status.present? && User.statuses.key?(requested_status)
            scope = scope.where(status: requested_status)
          end

          if params[:role].present? && User.roles.key?(params[:role])
            scope = scope.where(role: params[:role])
          end

          if params[:q].present?
            keyword = params[:q].to_s.strip.downcase
            escaped = ActiveRecord::Base.sanitize_sql_like(keyword)
            scope = scope.left_outer_joins(:user_profile).where(
              "LOWER(users.email) LIKE :keyword OR LOWER(user_profiles.display_name) LIKE :keyword OR LOWER(user_profiles.full_name) LIKE :keyword",
              keyword: "%#{escaped}%"
            )
          end

          users, pagination = paginated(scope)

          render_success(
            {
              users: users.map { |user| admin_user_summary_json(user) },
              pagination: pagination
            }
          )
        end

        def show
          user = User
            .includes(
              :user_profile,
              :app_memberships,
              :terms_acceptances,
              :auth_sessions,
              :coconique_safety_check_setting,
              :coconique_emergency_contacts,
              :coconique_user_restrictions,
              :coconique_user_admin_notes,
              :given_coconique_feedbacks,
              :received_coconique_feedbacks,
              :hosted_coconique_events,
              coconique_user_blocks_as_blocker: [:blocked, :coconique_report, :lifted_by],
              coconique_user_blocks_as_blocked: [:blocker, :coconique_report, :lifted_by],
              coconique_participation_requests: :coconique_event,
              coconique_reports: [:reported_user, :coconique_event],
              reported_coconique_reports: [:reporter, :coconique_event]
            )
            .find(params[:id])

          render_success({ user: admin_user_detail_json(user) })
        end

        def status
          user = User.find(params[:id])
          next_status = params.require(:status)

          unless User.statuses.key?(next_status)
            return render_error(
              code: "INVALID_STATUS",
              message: "指定されたステータスは使用できません。",
              status: :unprocessable_entity
            )
          end

          if user.id == current_user.id && next_status != "active"
            return render_error(
              code: "CANNOT_CHANGE_OWN_STATUS",
              message: "自分自身のアカウントを停止・削除状態に変更することはできません。",
              status: :unprocessable_entity
            )
          end

          user.update!(status: next_status)

          if next_status != "active"
            user.auth_sessions.active.update_all(
              revoked_at: Time.current,
              updated_at: Time.current
            )
          end

          AuditLog.record!(
            user: current_user,
            action: "admin.user_status_updated",
            request: request,
            target: user,
            metadata: {
              status: next_status
            }
          )

          render_success({ user: admin_user_detail_json(user.reload) })
        end

        def add_note
          user = User.find(params[:id])
          body = params.require(:body).to_s

          note = user.coconique_user_admin_notes.create!(
            admin_user: current_user,
            body: body,
            metadata: { source: "admin_user_detail" }
          )

          AuditLog.record!(
            user: current_user,
            action: "admin.coconique_user_admin_note.created",
            request: request,
            target: user,
            metadata: { note_public_id: note.public_id }
          )

          render_success({ user: admin_user_detail_json(user.reload) }, status: :created)
        end

        private

        def admin_user_summary_json(user)
          profile = user.user_profile
          active_restriction = active_coconique_restriction_json(user)
          safety_setting = user.coconique_safety_check_setting
          contacts = user.coconique_emergency_contacts

          {
            "id" => user.id.to_s,
            "email" => user.email,
            "displayName" => profile&.display_name || user.email.to_s.split("@").first,
            "avatarUrl" => profile&.avatar_url,
            "emailVerified" => user.email_verified_at.present?,
            "status" => user.status,
            "role" => user.role,
            "createdAt" => user.created_at&.iso8601,
            "lastLoginAt" => user.last_login_at&.iso8601,
            "identityVerification" => identity_verification_json(profile),
            "safetyCheck" => safety_check_summary_json(safety_setting),
            "emergencyContacts" => emergency_contact_summary_json(contacts),
            "activeRestriction" => active_restriction,
            "feedbackSummary" => CoconiqueFeedback.admin_summary_for_host(user),
            "reportsMadeCount" => user.coconique_reports.count,
            "reportsReceivedCount" => user.reported_coconique_reports.count,
            "hostedEventsCount" => user.hosted_coconique_events.count,
            "participationsCount" => user.coconique_participation_requests.count
          }
        end

        def admin_user_detail_json(user)
          admin_user_summary_json(user).merge(
            "profile" => admin_profile_json(user.user_profile),
            "hostedEvents" => user.hosted_coconique_events.order(created_at: :desc).limit(30).map { |event| admin_event_json(event) },
            "participations" => user.coconique_participation_requests.order(created_at: :desc).limit(50).map { |request| admin_participation_json(request) },
            "reportsMade" => user.coconique_reports.order(created_at: :desc).limit(50).map { |report| admin_report_brief_json(report) },
            "reportsReceived" => user.reported_coconique_reports.order(created_at: :desc).limit(50).map { |report| admin_report_brief_json(report) },
            "restrictions" => user.coconique_user_restrictions.order(created_at: :desc, id: :desc).limit(50).map { |restriction| admin_restriction_json(restriction) },
            "blocksMade" => user.coconique_user_blocks_as_blocker.order(created_at: :desc, id: :desc).limit(50).map { |block| admin_user_block_json(block) },
            "blocksReceived" => user.coconique_user_blocks_as_blocked.order(created_at: :desc, id: :desc).limit(50).map { |block| admin_user_block_json(block) },
            "feedbacksGiven" => user.given_coconique_feedbacks.includes(:host, :coconique_event).ordered_recently.limit(50).map { |feedback| admin_feedback_json(feedback) },
            "feedbacksReceived" => user.received_coconique_feedbacks.includes(:user, :coconique_event).ordered_recently.limit(50).map { |feedback| admin_feedback_json(feedback) },
            "adminNotes" => user.coconique_user_admin_notes.ordered_recently.limit(50).map { |note| admin_note_json(note) },
            "appMemberships" => user.app_memberships.order(created_at: :desc).map { |membership| admin_membership_json(membership) },
            "termsAcceptances" => user.terms_acceptances.order(accepted_at: :desc).limit(10).map { |acceptance| admin_terms_acceptance_json(acceptance) },
            "authSessions" => user.auth_sessions.order(created_at: :desc).limit(10).map { |session| auth_session_json(session) }
          )
        end

        def admin_profile_json(profile)
          return nil if profile.blank?

          {
            "id" => profile.id,
            "displayName" => profile.display_name,
            "fullName" => profile.full_name,
            "legalLastName" => profile.legal_last_name,
            "legalFirstName" => profile.legal_first_name,
            "legalMiddleName" => profile.legal_middle_name,
            "legalLastNameKana" => profile.legal_last_name_kana,
            "legalFirstNameKana" => profile.legal_first_name_kana,
            "legalMiddleNameKana" => profile.legal_middle_name_kana,
            "identityBirthDate" => profile.identity_birth_date&.iso8601,
            "identityGender" => profile.identity_gender,
            "publicAgeLabel" => profile.public_age_label,
            "headline" => profile.profile_headline,
            "bio" => profile.bio,
            "interestCategoryKeys" => profile.interest_category_keys || [],
            "participationStyleKeys" => profile.participation_style_keys || [],
            "preferredAreas" => profile.preferred_areas || [],
            "conversationTopics" => profile.conversation_topics || [],
            "communicationPreferences" => profile.communication_preferences || [],
            "clubLoveLevels" => profile.club_love_levels || {},
            "avatarUrl" => profile.avatar_url,
            "createdAt" => profile.created_at&.iso8601,
            "updatedAt" => profile.updated_at&.iso8601
          }
        end

        def identity_verification_json(profile)
          status = if profile.blank?
            "not_started"
          elsif profile.legal_last_name.present? && profile.legal_first_name.present? && profile.identity_birth_date.present? && profile.identity_gender.present?
            "profile_entered"
          else
            "incomplete"
          end

          {
            "status" => status,
            "hasLegalName" => profile.present? && profile.legal_last_name.present? && profile.legal_first_name.present?,
            "hasBirthDate" => profile.present? && profile.identity_birth_date.present?,
            "hasGender" => profile.present? && profile.identity_gender.present?,
            "note" => "MVPでは本人確認書類照合は未実装。プロフィール本人情報の入力状態を表示しています。"
          }
        end

        def safety_check_summary_json(setting)
          return { "enabled" => false, "mode" => "off" } if setting.blank?

          {
            "enabled" => setting.effective_enabled?,
            "mode" => setting.mode,
            "startDelayMinutes" => setting.start_delay_minutes,
            "reminderIntervalMinutes" => setting.reminder_interval_minutes,
            "maxReminders" => setting.max_reminders,
            "notifyContactsOnNoResponse" => setting.notify_contacts_on_no_response,
            "notifyContactsOnHelp" => setting.notify_contacts_on_help,
            "shareEventTitle" => setting.share_event_title,
            "shareEventArea" => setting.share_event_area,
            "enabledSince" => setting.enabled_since&.iso8601,
            "disabledAt" => setting.disabled_at&.iso8601,
            "updatedAt" => setting.updated_at&.iso8601
          }
        end

        def emergency_contact_summary_json(contacts)
          records = Array(contacts).map do |contact|
            {
              "id" => contact.public_id,
              "name" => contact.name,
              "email" => contact.email,
              "status" => contact.status,
              "lastInvitedAt" => contact.last_invited_at&.iso8601,
              "approvedAt" => contact.approved_at&.iso8601,
              "revokedAt" => contact.revoked_at&.iso8601
            }
          end

          {
            "count" => records.size,
            "approvedCount" => records.count { |contact| contact["status"] == "approved" },
            "pendingCount" => records.count { |contact| contact["status"] == "pending" },
            "contacts" => records
          }
        end

        def admin_event_json(event)
          {
            "id" => event.public_id,
            "title" => event.title,
            "status" => event.status,
            "categoryKey" => event.category_key,
            "area" => event.area,
            "startsAt" => event.starts_at&.iso8601,
            "endsAt" => event.ends_at&.iso8601,
            "currentParticipants" => event.current_participants,
            "createdAt" => event.created_at&.iso8601
          }
        end

        def admin_participation_json(request)
          {
            "id" => request.public_id,
            "status" => request.status,
            "message" => request.message,
            "attendanceStatus" => request.attendance_status,
            "attendanceRecordedAt" => request.attendance_recorded_at&.iso8601,
            "createdAt" => request.created_at&.iso8601,
            "event" => admin_event_json(request.coconique_event)
          }
        end

        def admin_report_brief_json(report)
          {
            "id" => report.public_id,
            "createdAt" => report.created_at&.iso8601,
            "targetType" => report.target_type,
            "reason" => report.reason,
            "status" => report.status,
            "severity" => report.severity,
            "eventStatusAtReport" => report.event_status_at_report,
            "reportPhase" => report.report_phase,
            "otherUser" => admin_user_brief_json(report.reporter_id == report.reported_user_id ? nil : (report.reporter || report.reported_user)),
            "event" => report.coconique_event && admin_event_json(report.coconique_event)
          }
        end

        def admin_restriction_json(restriction)
          {
            "id" => restriction.public_id,
            "status" => restriction.status,
            "reason" => restriction.reason,
            "note" => restriction.note,
            "startsAt" => restriction.starts_at&.iso8601,
            "endsAt" => restriction.ends_at&.iso8601,
            "liftedAt" => restriction.lifted_at&.iso8601,
            "active" => restriction.active_now?,
            "createdAt" => restriction.created_at&.iso8601,
            "createdByAdmin" => admin_user_brief_json(restriction.created_by_admin),
            "liftedByAdmin" => admin_user_brief_json(restriction.lifted_by_admin),
            "report" => restriction.coconique_report && admin_report_brief_json(restriction.coconique_report)
          }
        end


        def admin_user_block_json(block)
          return nil if block.blank?

          {
            "id" => block.public_id,
            "reason" => block.reason,
            "reasonLabel" => CoconiqueUserBlock::REASON_LABELS[block.reason] || CoconiqueUserBlock::REASON_LABELS["other"],
            "note" => block.note,
            "active" => block.active?,
            "createdAt" => block.created_at&.iso8601,
            "liftedAt" => block.lifted_at&.iso8601,
            "blocker" => admin_user_brief_json(block.blocker),
            "blocked" => admin_user_brief_json(block.blocked),
            "liftedBy" => admin_user_brief_json(block.lifted_by),
            "report" => block.coconique_report && admin_report_brief_json(block.coconique_report)
          }
        end

        def admin_feedback_json(feedback)
          {
            "id" => feedback.public_id,
            "safetyAnswer" => feedback.safety_answer,
            "accuracyAnswer" => feedback.accuracy_answer,
            "joinAgainAnswer" => feedback.join_again_answer,
            "privateNote" => feedback.private_note,
            "status" => feedback.status,
            "publicCountable" => feedback.public_countable,
            "needsSupportFollowup" => feedback.needs_support_followup?,
            "createdAt" => feedback.created_at&.iso8601,
            "event" => admin_event_json(feedback.coconique_event),
            "user" => admin_user_brief_json(feedback.user),
            "host" => admin_user_brief_json(feedback.host)
          }
        end

        def admin_note_json(note)
          {
            "id" => note.public_id,
            "body" => note.body,
            "createdAt" => note.created_at&.iso8601,
            "adminUser" => admin_user_brief_json(note.admin_user)
          }
        end

        def admin_membership_json(membership)
          {
            "id" => membership.id,
            "appKey" => membership.app_key,
            "status" => membership.status,
            "startedAt" => membership.started_at&.iso8601,
            "createdAt" => membership.created_at&.iso8601
          }
        end

        def admin_terms_acceptance_json(acceptance)
          {
            "id" => acceptance.id,
            "appKey" => acceptance.app_key,
            "termsVersion" => acceptance.terms_version,
            "privacyVersion" => acceptance.privacy_version,
            "acceptedAt" => acceptance.accepted_at&.iso8601
          }
        end

        def auth_session_json(session)
          {
            "id" => session.id,
            "userId" => session.user_id,
            "expiresAt" => session.expires_at&.iso8601,
            "revokedAt" => session.revoked_at&.iso8601,
            "ipAddress" => session.ip_address,
            "userAgent" => session.user_agent,
            "createdAt" => session.created_at&.iso8601,
            "active" => session.revoked_at.nil? && session.expires_at.future?
          }
        end

        def admin_user_brief_json(user)
          return nil if user.blank?

          profile = user.user_profile
          {
            "id" => user.id.to_s,
            "email" => user.email,
            "displayName" => profile&.display_name || user.email.to_s.split("@").first,
            "avatarUrl" => profile&.avatar_url,
            "status" => user.status,
            "role" => user.role
          }
        end
      end
    end
  end
end
