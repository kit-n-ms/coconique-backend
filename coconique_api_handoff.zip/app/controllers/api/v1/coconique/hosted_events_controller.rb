module Api
  module V1
    module Coconique
      class HostedEventsController < BaseController
        def index
          events = current_user.hosted_coconique_events.hosted_ordered

          if params[:status].present? && CoconiqueEvent.statuses.key?(params[:status])
            events = events.where(status: params[:status])
          end

          if params[:q].present?
            query = "%#{ActiveRecord::Base.sanitize_sql_like(params[:q].to_s)}%"
            events = events.where(
              "title ILIKE :query OR area ILIKE :query OR summary ILIKE :query",
              query: query
            )
          end

          render_success(
            {
              events: events.map { |event| serialize_host_event(event) }
            }
          )
        end
      end
    end
  end
end
