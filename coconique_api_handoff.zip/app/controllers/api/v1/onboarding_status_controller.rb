module Api
  module V1
    class OnboardingStatusController < ApplicationController
      before_action :require_login!

      def show
        app_key = params.fetch(:app_key, "sample_app")

        profile_completed = current_user.user_profile.present?

        terms_accepted = current_user.terms_acceptances.exists?(
          app_key: app_key,
          terms_version: ENV.fetch("CURRENT_TERMS_VERSION", "2026-05-01"),
          privacy_version: ENV.fetch("CURRENT_PRIVACY_VERSION", "2026-05-01")
        )

        app_membership_started = current_user.app_memberships.exists?(
          app_key: app_key,
          status: :active
        )

        render_success(
          {
            onboarding: {
              app_key: app_key,
              email_verified: current_user.email_verified?,
              profile_completed: profile_completed,
              terms_accepted: terms_accepted,
              app_membership_started: app_membership_started,
              next_step: next_step(
                email_verified: current_user.email_verified?,
                profile_completed: profile_completed,
                terms_accepted: terms_accepted,
                app_membership_started: app_membership_started
              )
            }
          }
        )
      end

      private

      def next_step(email_verified:, profile_completed:, terms_accepted:, app_membership_started:)
        return "email_verification" unless email_verified
        return "profile" unless profile_completed
        return "terms" unless terms_accepted
        return "start" unless app_membership_started

        "dashboard"
      end
    end
  end
end
