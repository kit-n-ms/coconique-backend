class CreditTransaction < ApplicationRecord
  belongs_to :user
  belongs_to :credit_balance

  validates :app_key, presence: true
  validates :transaction_type, presence: true
  validates :amount, numericality: { other_than: 0 }
  validates :balance_after, numericality: { greater_than_or_equal_to: 0 }
end