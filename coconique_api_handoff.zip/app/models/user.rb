class User < ApplicationRecord
  has_secure_password

  has_one :user_profile, dependent: :destroy

  has_many :auth_sessions, dependent: :destroy
  has_many :email_verifications, dependent: :destroy
  has_many :password_resets, dependent: :destroy
  has_many :terms_acceptances, dependent: :destroy
  has_many :app_memberships, dependent: :destroy
  has_many :audit_logs, dependent: :nullify

  has_many :hosted_coconique_events,
    class_name: "CoconiqueEvent",
    foreign_key: :host_id,
    dependent: :nullify
  has_many :coconique_event_favorites, dependent: :destroy
  has_many :favorite_coconique_events,
    through: :coconique_event_favorites,
    source: :coconique_event
  has_many :coconique_participation_requests, dependent: :destroy
  has_many :coconique_event_messages, dependent: :destroy
  has_many :coconique_event_message_reactions, dependent: :destroy
  has_many :coconique_event_chat_reads, dependent: :destroy
  has_many :coconique_notifications, dependent: :destroy
  has_many :coconique_emergency_contacts, dependent: :destroy
  has_one :coconique_safety_check_setting, dependent: :destroy
  has_many :coconique_safety_check_sessions, dependent: :destroy
  has_many :coconique_reports, foreign_key: :reporter_id, dependent: :nullify
  has_many :reported_coconique_reports, class_name: "CoconiqueReport", foreign_key: :reported_user_id, dependent: :nullify
  has_many :given_coconique_feedbacks, class_name: "CoconiqueFeedback", foreign_key: :user_id, dependent: :destroy
  has_many :received_coconique_feedbacks, class_name: "CoconiqueFeedback", foreign_key: :host_id, dependent: :nullify
  has_many :coconique_user_restrictions, dependent: :destroy
  has_many :coconique_user_admin_notes, dependent: :destroy
  has_many :coconique_user_blocks_as_blocker,
    class_name: "CoconiqueUserBlock",
    foreign_key: :blocker_id,
    dependent: :destroy
  has_many :coconique_user_blocks_as_blocked,
    class_name: "CoconiqueUserBlock",
    foreign_key: :blocked_id,
    dependent: :destroy

  has_one :stripe_customer, dependent: :destroy

  has_many :payment_checkout_sessions, dependent: :destroy
  has_many :credit_balances, dependent: :destroy
  has_many :credit_transactions, dependent: :destroy

  enum :status, {
    active: 0,
    suspended: 1,
    deleted: 2,
    banned: 3
  }

  enum :role, {
    general: 0,
    admin: 10
  }

  before_validation :normalize_email

  validates :email,
    presence: true,
    uniqueness: true,
    format: { with: URI::MailTo::EMAIL_REGEXP }

  validates :password,
    length: { minimum: 12 },
    if: -> { password.present? }

  def email_verified?
    email_verified_at.present?
  end

  private

  def normalize_email
    self.email = email.to_s.strip.downcase
  end
end