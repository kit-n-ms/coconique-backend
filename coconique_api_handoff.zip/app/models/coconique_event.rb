class CoconiqueEvent < ApplicationRecord
  CATEGORY_KEYS = %w[culture walk watching cafe seasonal].freeze

  belongs_to :host, class_name: "User", optional: true

  has_many :coconique_event_favorites, dependent: :destroy
  has_many :favorited_users,
    through: :coconique_event_favorites,
    source: :user

  has_many :coconique_participation_requests, dependent: :destroy
  has_many :coconique_event_status_logs, dependent: :destroy
  has_many :coconique_event_messages, dependent: :destroy
  has_many :coconique_feedbacks, dependent: :destroy
  has_many :coconique_event_chat_reads, dependent: :destroy
  has_many :participants,
    through: :coconique_participation_requests,
    source: :user

  enum :status, {
    draft: 0,
    reviewing: 10,
    recruiting: 20,
    closed: 30,
    confirmed: 40,
    finished: 50,
    canceled: 60
  }

  before_validation :ensure_public_id, on: :create
  before_validation :normalize_target_members
  before_validation :normalize_member_visibility_flags
  before_validation :normalize_area_region
  before_validation :normalize_image_urls

  validates :public_id, presence: true, uniqueness: true
  validates :title, presence: true, length: { maximum: 120 }
  validates :category_key, presence: true, inclusion: { in: CATEGORY_KEYS }
  validates :area, presence: true, length: { maximum: 120 }
  validates :area_prefecture, length: { maximum: 20 }, allow_blank: true
  validates :area_city, length: { maximum: 40 }, allow_blank: true
  validates :starts_at, :ends_at, presence: true
  validates :meeting_place, presence: true, length: { maximum: 180 }
  validates :reference_url, length: { maximum: 500 }, allow_blank: true
  validates :cancellation_reason, length: { maximum: 1000 }, allow_blank: true
  validate :image_urls_limit
  validates :capacity, numericality: { only_integer: true, greater_than: 0, less_than_or_equal_to: 30 }
  validates :min_participants, numericality: { only_integer: true, greater_than: 0, less_than_or_equal_to: 30 }
  validates :current_participants, numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validates :interested_count, numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validate :ends_at_after_starts_at
  validate :recruitment_ends_at_before_starts_at
  validate :min_participants_within_capacity

  scope :upcoming, -> { where("starts_at >= ?", Time.current).order(:starts_at, :id) }
  scope :visible_to_members, -> { where(status: [:recruiting, :confirmed]) }
  scope :accepting_applications, -> { where("recruitment_ends_at IS NULL OR recruitment_ends_at > ?", Time.current) }
  scope :with_available_slots, -> { where("current_participants < capacity") }
  scope :ordered_for_dashboard, -> { visible_to_members.accepting_applications.with_available_slots.where("ends_at > ?", Time.current).order(:starts_at, :id) }
  scope :hosted_ordered, -> { order(starts_at: :asc, id: :asc) }

  scope :finish_due, ->(now = Time.current) {
    where(status: [:recruiting, :confirmed, :closed])
      .where("ends_at <= ?", now)
      .order(:ends_at, :id)
  }

  def self.finish_due_events!(now: Time.current)
    finish_due(now).find_each do |event|
      event.with_lock do
        event.reload
        next unless event.recruiting? || event.confirmed? || event.closed?
        next if event.ends_at.blank? || event.ends_at > now

        previous_status = event.status
        event.finish!
        event.coconique_event_status_logs.create!(
          user: nil,
          action: "coconique.event.auto_finished",
          from_status: previous_status,
          to_status: event.status,
          reason: "終了予定時刻を過ぎたため自動的に終了済みにしました。"
        )
      end
    rescue StandardError => e
      Rails.logger.warn("[CoconiqueEvent] failed to auto finish event #{event&.id}: #{e.class} #{e.message}")
      next
    end
  end


  def self.cancel_open_events_for_restricted_user!(user, reason:)
    return 0 if user.blank?

    count = 0
    where(host_id: user.id, status: [:recruiting, :confirmed, :closed]).find_each do |event|
      event.with_lock do
        event.reload
        next unless event.recruiting? || event.confirmed? || event.closed?

        previous_status = event.status
        event.cancel!(reason: reason)
        event.coconique_event_status_logs.create!(
          user: nil,
          action: "coconique.event.canceled_by_user_restriction",
          from_status: previous_status,
          to_status: event.status,
          reason: reason
        )
        count += 1
      end
    rescue StandardError => e
      Rails.logger.warn("[CoconiqueEvent] failed to cancel restricted user's event #{event&.id}: #{e.class} #{e.message}")
      next
    end

    count
  end

  def favorited_by?(user)
    return false if user.blank? || new_record?

    coconique_event_favorites.exists?(user_id: user.id)
  end

  def participation_request_for(user)
    return nil if user.blank? || new_record?

    # 取り下げ後の再申請では、古い withdrawn 履歴と新しい pending 申請が併存する。
    # 募集詳細のボタン制御や集合場所の表示判定では、現在効いている申請を優先する。
    coconique_participation_requests
      .where(user_id: user.id, status: CoconiqueParticipationRequest::CURRENT_REQUEST_STATUSES)
      .order(created_at: :desc, id: :desc)
      .first ||
      coconique_participation_requests
        .where(user_id: user.id)
        .order(created_at: :desc, id: :desc)
        .first
  end

  def hosted_by?(user)
    return false if user.blank?

    host_id == user.id
  end

  def visible_to?(user)
    (visible_to_members_status? && recruitment_open?) || hosted_by?(user) || user&.admin?
  end

  def visible_to_members_status?
    recruiting? || confirmed?
  end

  def recruitment_open?
    recruitment_ends_at.blank? || recruitment_ends_at > Time.current
  end

  def publish!
    update!(
      status: :recruiting,
      published_at: published_at || Time.current,
      closed_at: nil,
      canceled_at: nil,
      finished_at: nil,
      cancellation_reason: nil
    )
  end

  def close!
    update!(
      status: :closed,
      closed_at: Time.current
    )
  end

  def reopen!
    update!(
      status: :recruiting,
      published_at: published_at || Time.current,
      closed_at: nil
    )
  end

  def cancel!(reason: nil)
    transaction do
      update!(
        status: :canceled,
        canceled_at: Time.current,
        cancellation_reason: reason.presence || cancellation_reason
      )

      clear_favorites!
    end
  end

  def finish!
    transaction do
      update!(
        status: :finished,
        finished_at: Time.current
      )

      clear_favorites!
    end
  end

  private

  def clear_favorites!
    coconique_event_favorites.destroy_all
  end

  def ensure_public_id
    self.public_id = "evt-#{SecureRandom.hex(8)}" if public_id.blank?
  end

  def normalize_target_members
    self.target_members = Array(target_members).map(&:to_s).reject(&:blank?)
  end

  def normalize_area_region
    self.area_prefecture = area_prefecture.to_s.strip.presence
    self.area_city = area_city.to_s.strip.presence

    if area_prefecture.present?
      self.area = [area_prefecture, area_city].compact_blank.join(" ")
    else
      self.area = area.to_s.strip.presence
    end
  end

  def normalize_member_visibility_flags
    self.same_gender_only = ActiveModel::Type::Boolean.new.cast(same_gender_only)
    self.same_generation_only = ActiveModel::Type::Boolean.new.cast(same_generation_only)
  end

  def normalize_image_urls
    self.image_urls = Array(image_urls).map(&:to_s).reject(&:blank?).first(5)
    self.image_url = image_urls.first if image_url.blank? && image_urls.present?
  end

  def image_urls_limit
    return if image_urls.blank? || image_urls.length <= 5

    errors.add(:image_urls, "must be 5 or fewer")
  end

  def ends_at_after_starts_at
    return if starts_at.blank? || ends_at.blank?
    return if ends_at > starts_at

    errors.add(:ends_at, "must be after starts_at")
  end

  def recruitment_ends_at_before_starts_at
    return if recruitment_ends_at.blank? || starts_at.blank?
    return if recruitment_ends_at < starts_at

    errors.add(:recruitment_ends_at, "must be before starts_at")
  end

  def min_participants_within_capacity
    return if min_participants.blank? || capacity.blank?
    return if min_participants <= capacity

    errors.add(:min_participants, "must be less than or equal to capacity")
  end
end
