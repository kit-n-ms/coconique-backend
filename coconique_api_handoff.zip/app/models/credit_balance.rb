class CreditBalance < ApplicationRecord
  belongs_to :user
  has_many :credit_transactions, dependent: :destroy

  validates :app_key, presence: true
  validates :balance, numericality: { greater_than_or_equal_to: 0 }

  def self.find_or_create_for!(user:, app_key:)
    find_or_create_by!(user: user, app_key: app_key) do |balance|
      balance.balance = 0
    end
  end

  def add_credit!(amount:, source:, description:, metadata: {})
    raise ArgumentError, "amount must be positive" unless amount.positive?

    transaction do
      lock!

      next_balance = balance + amount

      update!(balance: next_balance)

      credit_transactions.create!(
        user: user,
        app_key: app_key,
        transaction_type: "purchase",
        amount: amount,
        balance_after: next_balance,
        source_type: source.class.name,
        source_id: source.id.to_s,
        description: description,
        metadata: metadata || {}
      )
    end
  end
end