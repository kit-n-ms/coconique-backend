module AuthRequestHelper
  TEST_PASSWORD = "password123456"

  def csrf_cookie_name
    ENV.fetch("CSRF_COOKIE_NAME", "km_auth_starter_csrf")
  end

  def request_csrf!
    get "/api/v1/auth/csrf"
    assert_response :success
    cookies[csrf_cookie_name] || response.cookies[csrf_cookie_name]
  end

  def csrf_headers
    token = cookies[csrf_cookie_name] || response.cookies[csrf_cookie_name]
    { "X-CSRF-Token" => token.to_s }
  end

  def json_headers(extra = {})
    { "Content-Type" => "application/json" }.merge(extra)
  end

  def create_test_user!(email: "user-#{SecureRandom.hex(6)}@example.test", password: TEST_PASSWORD, verified: true, admin: false)
    User.create!(
      email: email,
      password: password,
      password_confirmation: password,
      email_verified_at: verified ? Time.current : nil,
      role: admin ? :admin : :general
    )
  end

  def login_as!(user, password: TEST_PASSWORD)
    request_csrf!
    post "/api/v1/auth/login",
      params: { email: user.email, password: password }.to_json,
      headers: json_headers(csrf_headers)
    assert_response :success
    user
  end
end
